package br.com.livroandroid.carros.fragments

import android.support.v4.app.Fragment

open class BaseFragment : Fragment() {
    // Métodos comuns para todos fragments aqui...
}
